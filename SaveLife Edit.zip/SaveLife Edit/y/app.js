const body = document.querySelector('body'),
      sidebar = body.querySelector('nav'),
      toggle = body.querySelector(".toggle"),
      searchBtn = body.querySelector(".search-box"),
      modeSwitch = body.querySelector(".toggle-switch"),
      modeText = body.querySelector(".mode-text");


toggle.addEventListener("click" , () =>{
    sidebar.classList.toggle("close");
})

searchBtn.addEventListener("click" , () =>{
    sidebar.classList.remove("close");
})

modeSwitch.addEventListener("click" , () =>{
    body.classList.toggle("dark");
    
    if(body.classList.contains("dark")){
        modeText.innerText = "Light mode";
    }else{
        modeText.innerText = "Dark mode";
        
    }
});

const optionMenu = document.querySelector(".select-menu"),
selectBtn = optionMenu.querySelector(".select-btn"),
options = optionMenu.querySelectorAll(".option"),
sBtn_text = optionMenu.querySelector(".sBtn-text");

selectBtn.addEventListener("click", () => optionMenu.classList.toggle("active"));       

options.forEach(option =>{
option.addEventListener("click", ()=>{
 let selectedOption = option.querySelector(".option-text").innerText;
 sBtn_text.innerText = selectedOption;

 optionMenu.classList.remove("active");
});
});

const ctx = document.getElementById('myChart');

        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['หนองปลาไหล', 'นาเกลือ', 'หนองปรือ', 'ห้วยใหญ่', 'เกาะล้าน'],
                datasets: [{
                    label: 'บาดเจ็บ',
                    data: [2294, 430, 273, 143, 0],
                    backgroundColor: [
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)'                   
                    ],
                    borderColor: [
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)',
                        'rgba(164,231,249,255)'  
                    ],
                    borderWidth: 1
                }, {
                    label: 'เสียชีวิต',
                    data: [22, 3, 8, 4, 0],
                    backgroundColor: [
                        'rgb(61,171,243)',
                        'rgb(61,171,243)',
                        'rgb(61,171,243)',
                        'rgb(61,171,243)',
                        'rgb(61,171,243)',
                        'rgb(61,171,243)'
                    ],
                    borderColor: [
                        'rgb(61,171,243)',
                        'rgb(61,171,243)',
                        'rgb(61,171,243)',
                        'rgb(61,171,243)',
                        'rgb(61,171,243)',
                        'rgb(61,171,243)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        
        var marker = new longdo.Marker({ lon: 100.60, lat: 12.60 });

        var marker1 = new longdo.Marker({ lon: 101.2, lat: 12.8 },
            {
                title: 'Marker',
                icon: {
                    url: 'https://map.longdo.com/mmmap/images/pin_mark.png',
                    offset: { x: 12, y: 45 }
                },
                detail: 'Drag me',
                visibleRange: { min: 7, max: 9 },
                draggable: true,
                weight: longdo.OverlayWeight.Top,
            });

        var marker = new longdo.Marker({ lon: 100.60, lat: 12.60 });

        var marker1 = new longdo.Marker({ lon: 101.2, lat: 12.8 },
            {
                title: 'Marker',
                icon: {
                    url: 'https://map.longdo.com/mmmap/images/pin_mark.png',
                    offset: { x: 12, y: 45 }
                },
                detail: 'Drag me',
                visibleRange: { min: 7, max: 9 },
                draggable: true,
                weight: longdo.OverlayWeight.Top,
            });

        var map;
        var search;

        function init() {
            map = new longdo.Map({
                placeholder: document.getElementById('map')
            });
            search = document.getElementById('search');

            map.Search.placeholder(
                document.getElementById('result')
            );

            search.onkeyup = function (event) {
                if ((event || window.event).keyCode != 13)
                    return;
                doSearch();
            }

            search.oninput = function () {
                if (search.value.length < 3) {
                    suggest.style.display = 'none';
                    return;
                }

                map.Search.suggest(search.value, {
                    area: 20150
                });
            };

            function doSearch() {
                map.Search.search(search.value, {
                    area: 20150,

                });
                suggest.style.display = 'none';
            }

            map.location({ lon: 100, lat: 16 }, true);
            map.location(longdo.LocationMode.Geolocation);

            map.Layers.setBase(longdo.Layers.GRAY);
            map.Overlays.add(marker);
            map.Overlays.add(marker1);
        }

